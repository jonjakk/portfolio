<?php
namespace Bookly\Frontend\Modules\Booking\Proxy;

use Bookly\Lib as BooklyLib;

/**
 * Class CustomerGroups
 * @package Bookly\Frontend\Modules\Booking\Proxy
 *
 * @method static void renderCartDiscountRow( array $table, $layout )
 */
abstract class CustomerGroups extends BooklyLib\Base\Proxy
{
}