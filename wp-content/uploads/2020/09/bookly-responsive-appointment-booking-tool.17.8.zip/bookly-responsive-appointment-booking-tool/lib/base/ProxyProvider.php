<?php
namespace Bookly\Lib\Base;

/**
 * Class ProxyProvider
 * @deprecated
 * @package Bookly\Lib\Base
 */
abstract class ProxyProvider
{
    public static function registerMethods(){}
}