<?php
namespace Bookly\Lib\Proxy;

use Bookly\Lib;

/**
 * Class CollaborativeServices
 * @package Bookly\Lib\Proxy
 *
 */
abstract class CollaborativeServices extends Lib\Base\Proxy
{

}