<?php
namespace Bookly\Lib\Proxy;

use Bookly\Lib;

/**
 * Class CompoundServices
 * @package Bookly\Lib\Proxy
 *
 */
abstract class CompoundServices extends Lib\Base\Proxy
{

}