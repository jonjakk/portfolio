<?php
namespace Bookly\Backend\Modules\Customers\Proxy;

use Bookly\Lib;

/**
 * Class Shared
 * @package Bookly\Backend\Modules\Customers\Proxy
 *
 * @method static void mergeCustomers( int $target_id, array $ids ) Merge customers.
 */
abstract class Shared extends Lib\Base\Proxy
{

}