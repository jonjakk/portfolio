<?php
namespace Bookly\Backend\Components\Dialogs\Appointment\AttachPayment\Proxy;

use Bookly\Lib;

/**
 * Class Taxes
 * @package Bookly\Backend\Components\Dialogs\Appointment\AttachPayment\Proxy
 *
 * @method static void renderAttachPayment()
 */
abstract class Taxes extends Lib\Base\Proxy
{

}