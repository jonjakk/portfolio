<?php
namespace Bookly\Backend\Components\Dialogs\Appointment\CustomerDetails\Proxy;

use Bookly\Lib;

/**
 * Class Shared
 * @package Bookly\Backend\Components\Dialogs\Appointment
 *
 * @method static void renderDetails()
 */
abstract class Shared extends Lib\Base\Proxy
{

}