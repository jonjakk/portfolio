jQuery(function ($) {
    'use strict';

    $(document.body)
        .on('staff.saved', {},
            function (event, tab, staffData) {
                if (tab == 'staff-details') {
                    let staff = BooklyStaffOrderDialogL10n.staff
                        .find(s => s.id == staffData.id);

                    if (staff === undefined) {
                        BooklyStaffOrderDialogL10n.staff.push({id: staffData.id, full_name: staffData.full_name})
                    } else {
                        staff.full_name = staffData.full_name;
                    }
                }
            })
        .on('staff.deleted', {},
            function (event, staff) {
                BooklyStaffOrderDialogL10n.staff.forEach((s, index) => {
                    if (staff.includes(String(s.id))) {
                        delete BooklyStaffOrderDialogL10n.staff[index];
                    }
                });
                // Remove undefined values
                BooklyStaffOrderDialogL10n.staff.filter(function (el) {
                    return el != undefined;
                });
            });

    var $dialog   = $('#bookly-staff-order-modal'),
        $list     = $('#bookly-list', $dialog),
        $template = $('#bookly-staff-template'),
        $table    = $('#services-list'),
        $save     = $('#bookly-save', $dialog)
    ;

    // Save categories
    $save.on('click', function (e) {
        e.preventDefault();
        let ladda = Ladda.create(this),
            staff = [],
            list  = [];
        ladda.start();
        $('li', $list).each((index, elem) => {
            let id = $('[name="id"]', $(elem)).val();
            staff.push(id);
            list.push({id, full_name: $('.bookly-js-full_name', $(elem)).html()});
        });

        $.post(ajaxurl, {
                action: 'bookly_update_staff_positions',
                staff,
                csrf_token: BooklyStaffOrderDialogL10n.csrfToken
            },
            function (response) {
                if (response.success) {
                    $dialog.modal('hide');
                    BooklyStaffOrderDialogL10n.staff = list;
                }
                ladda.stop();
            });
    });

    $dialog.off().on('show.bs.modal', function () {
        $list.html('');
        BooklyStaffOrderDialogL10n.staff.forEach(function (staff) {
            $list.append(
                $template.clone().show().html()
                    .replace(/{{id}}/g, staff.id)
                    .replace(/{{full_name}}/g, staff.full_name)
            );
        });
    });

    $list.sortable({
        axis  : 'y',
        handle: '.bookly-js-draghandle',
    });
});