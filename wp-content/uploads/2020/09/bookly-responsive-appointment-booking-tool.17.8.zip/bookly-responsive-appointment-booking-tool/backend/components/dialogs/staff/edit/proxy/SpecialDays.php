<?php
namespace Bookly\Backend\Components\Dialogs\Staff\Edit\Proxy;

use Bookly\Lib;

/**
 * Class SpecialDays
 *
 * @package Bookly\Backend\Components\Dialogs\Staff\Edit\Proxy
 *
 * @method static string  getStaffSpecialDaysHtml( string $default, int $staff_id )
 */
abstract class SpecialDays extends Lib\Base\Proxy
{

}