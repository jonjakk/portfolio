<?php
namespace Bookly\Backend\Components\Dialogs\Staff\Categories\Proxy;

use Bookly\Lib as BooklyLib;

/**
 * Class Pro
 * @package Bookly\Backend\Components\Dialogs\Staff\Categories\Proxy
 *
 * @method static void renderDialog()
 * @method static void renderAdd()
 */
abstract class Pro extends BooklyLib\Base\Proxy
{
}