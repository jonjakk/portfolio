<?php
namespace Bookly\Backend\Components\Dialogs\Appointment\CustomerDetails\Proxy;

use Bookly\Lib;

/**
 * Class Files
 * @package Bookly\Backend\Components\Dialogs\Appointment
 *
 * @method static void renderCustomField( \stdClass $custom_field ) Render files in Customer Details
 */
abstract class Files extends Lib\Base\Proxy
{

}